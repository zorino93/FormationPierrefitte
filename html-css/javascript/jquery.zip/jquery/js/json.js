var myUsers2 = [
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F1.bp.blogspot.com%2F-ZQ72arN6Cww%2FVYwYGuHvIvI%2FAAAAAAAA5sU%2FODig-qk58ew%2Fs1600%2Fgabby-character-art.png",
    'name': "Juliette",
    'birthday': "1981-10-11"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F2.bp.blogspot.com%2F-5mRilOpRy0I%2FVJy6GQtKHPI%2FAAAAAAAAqgI%2Fgf9IjNNWct4%2Fs1600%2F20140619132911_pablo__1__by_kaylor2013-d8ajjmn.png",
    'name': "Jamel",
    'birthday': "1973-02-06"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F1.bp.blogspot.com%2F-nsswLeomtas%2FVPmvY91wJ8I%2FAAAAAAAAyBc%2Fi0HeUWxi2B0%2Fs1600%2Fcharacterart-ducktales-540b351b98bbf.png",
    'name': "Paul",
    'birthday': "1961-02-07"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F2.bp.blogspot.com%2F-AdUypBrvdDw%2FVYwRWktSfmI%2FAAAAAAAA5E8%2F2-5ZOLMGnwk%2Fs1600%2Fcandacepoint.png",
    'name': "Maryline",
    'birthday': "1969-02-08"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2F1.bp.blogspot.com%2F-9xdiTy7IjQk%2FWBL4dO7VSvI%2FAAAAAAABCUw%2FNfhpqM8IWQs1OlLV1AIFvEaJ4LdnrpNVgCPcB%2Fs1600%2FZingzillas_zak.png",
    'name': "José",
    'birthday': "1961-02-09"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fimg-new.cgtrader.com%2Fitems%2F49561%2Fdinosaur_cartoon_character_3d_model_3ds_fbx_c4d_dxf_lwo_lw_lws_ma_mb_obj_hrc_xsi_max_0d3762e0-4dd9-4a54-921a-b8a3727d02ed.jpg",
    'name': "Christian",
    'birthday': "1961-02-10"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F3.bp.blogspot.com%2F--B1o1aR9bMs%2FVhnCEKOBZHI%2FAAAAAAAA-U8%2FU2gAIpoIEOg%2Fs1600%2Fchar_pip.png",
    'name': "Ali",
    'birthday': "1961-02-11"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F2.bp.blogspot.com%2F-GRGZt1CRaJ4%2FUvh8q4j7IQI%2FAAAAAAAAZjc%2FtVUkrZi1H6Q%2Fs1600%2FJACKIE_05C.jpg",
    'name': "Pepita",
    'birthday': "1961-02-12"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2F3.bp.blogspot.com%2F-myyVqOupnX8%2FWh8SHSOaNaI%2FAAAAAAABNUo%2FsT09777VCBEgG57HOVejHUZgqyQDiam4ACKgBGAs%2Fs1600%2FCirque-Du-Soleil-Luna-Petunia-SABAN-616.png",
    'name': "Aline",
    'birthday': "1961-02-13"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fthumbs.dreamstime.com%2Fz%2Fwalking-butterfly-cartoon-character-d-rendered-illustration-69238085.jpg",
    'name': "Marcelle",
    'birthday': "1941-02-14"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fi.pinimg.com%2F736x%2F35%2F37%2F47%2F353747482e8b8a7e072609548a85398a--hanna-barbera-cartoons-secret-squirrel.jpg",
    'name': "Josh",
    'birthday': "1971-02-15"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2F4.bp.blogspot.com%2F-Ua-2EP5iNPI%2FU84WftNQd7I%2FAAAAAAAAghI%2F717a28yB9XQ%2Fs1600%2FDoramichan.png",
    'name': "Ana",
    'birthday': "1964-02-16"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Ftse2.mm.bing.net%2Fth%3Fid%3DOIP.9PAer7su1OTkRLu8dKrpagHaJS%26pid%3D15.1&f=1",
    'name': "Mounia",
    'birthday': "1969-02-17"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2F1.bp.blogspot.com%2F-5PfgYCz5xdI%2FU3mtwIj0JJI%2FAAAAAAAAfxs%2FQSMH0O3ntG8%2Fs1600%2F13.png",
    'name': "Nikita",
    'birthday': "1961-02-18"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2F3.bp.blogspot.com%2F-myyVqOupnX8%2FWh8SHSOaNaI%2FAAAAAAABNUo%2FsT09777VCBEgG57HOVejHUZgqyQDiam4ACKgBGAs%2Fs1600%2FCirque-Du-Soleil-Luna-Petunia-SABAN-616.png",
    'name': "Maria",
    'birthday': "1961-02-19"
  },
  {
    'img': "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2F2.bp.blogspot.com%2F-95s2I3alL6E%2FV3SMQgA9P_I%2FAAAAAAABAy0%2FKBu3-cA8dt4MHwZi5SfnjbRJMWKfMVFZQCKgB%2Fs1600%2Fguga_azul.png",
    'name': "Joel",
    'birthday': "1961-02-20"
  }
];