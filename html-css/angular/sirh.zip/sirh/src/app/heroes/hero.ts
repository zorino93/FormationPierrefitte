export class Hero {
    id: number;
    name: string;
    url: string;
}