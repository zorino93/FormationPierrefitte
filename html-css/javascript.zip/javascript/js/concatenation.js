//Variable de type String
var tomtom = "225"; 
//variable type Boolean
var toto = true; 
//variable type Number
var yancy = 1.09; 

calcul = tomtom + ' ' + toto + ' ' + yancy;

console.log(calcul);
document.write(calcul + "<br>");
//document.write(typeof (calcul));

var jour = 'Lundi', mois = 09, annee = 'Janvier';
document.write(jour + ' ' + mois + ' ' + annee);