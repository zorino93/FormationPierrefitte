/**
 * Contenu du fichier .js << tp1.js >> 
 */

document.getElementById("txt").innerText = "SALUT TOUT L'MONDE !!!";

console.log("javascript est lancé");