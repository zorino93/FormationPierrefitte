
var moyenne = Number(prompt("saisir la moyenne"));

if (moyenne < 10) {
    alert('recalé');
    console.log('recalé');
}

else if (moyenne >= 12) {
    alert('reçu avec mention');
    console.log('reçu avec mention');

}

else {
    alert('reçu');
    console.log('reçu');
}