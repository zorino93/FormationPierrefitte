var diese = "";

for (var i = 0; i < 7; i++) {
    diese += "#"
    document.write(diese + "<br>");
}

var ligne = "";
var i = 1;
while (i <= 7) {
    ligne = ligne + "#";
    document.write(ligne + "<br>");
    i++;

}