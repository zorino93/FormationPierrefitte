function change_style() {
    var p = document.querySelector('#parag1');
    p.style.color = '#fff';
    p.style.backgroundColor = 'rosyBrown';
    p.style.border = '6px dotted teal';
    p.style.padding = '#fff';
    p.style.width = "60%";
    p.style.margin = '0 auto';
}