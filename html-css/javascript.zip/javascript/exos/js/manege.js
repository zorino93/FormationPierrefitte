var ii= Number(prompt("saisir le nombre de tour"));

for (i = 1; i <= ii; i++) {
    document.write("C'est le tour de manège n°" + i + "<br>");
}