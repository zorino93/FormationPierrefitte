var nb1 = Number(prompt("saisir un nombre"));
var nb2 = Number(prompt("saisir autre nombre"));

if (nb1 > nb2) {
    alert(nb1 + " plus grand que" + ' ' + nb2);
}

else if (nb1 < nb2) {
    alert(nb1 + " plus petit que" + ' ' + nb2);
}

else {
    alert(nb1 + " égale à" + ' ' + nb2);
}


