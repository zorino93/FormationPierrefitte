var nombre1 = 5, nombre2 = 3; 
var vide = nombre1;
nombre1 = nombre2;
nombre2 = vide;
console.log(nombre1);
console.logog(nombre2);
document.write(nombre1);
document.write(nombre2);