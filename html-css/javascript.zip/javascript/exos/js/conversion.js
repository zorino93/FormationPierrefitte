var degre = Number(prompt("Saisir une température"));

fahrenheit = degre * 9 / 5 + 32;

alert(fahrenheit);
console.log(fahrenheit); /** Afficher dans la console */
document.write(fahrenheit);/** Afficher dans la page */