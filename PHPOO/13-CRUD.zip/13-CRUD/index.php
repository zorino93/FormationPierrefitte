<?php
 require_once( 'Autoload.php');

 $controller = new controller\Controller();

 $controller->handleRequest();